import React from 'react'
import Apifetch from './components/apifetch'

function App() {
  return (
    <div>
      <Apifetch />
    </div>
  )
}

export default App
