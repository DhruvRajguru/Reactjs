import React from 'react'

function Card({id,image,desc,title,price,brand}) {
  return (
    <div id='card' className='h-[30rem] w-[18rem] m-5 bg-neutral-100 border-2 border-black rounded-lg overflow-auto text-center'>
      <img src={image[0]} className='w-full h-1/2 p-1  border-b-2 border-blue-700 object-cover' />
      <p>id:{id}</p>
      <p>brand:{brand}</p>
      <p>desc:{desc}</p>
      <p>title:{title}</p>
      <p>price:{price}</p>
      
    </div>
  )
}

export default Card
