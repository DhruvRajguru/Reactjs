import React, { useEffect, useState } from 'react'
import Card from './Card'

function Apifetch() {
    const [data, setData] = useState([])

    const fetchdata =async()=>{
        const response=await fetch('https://dummyjson.com/products')
        const peoductdatas=await response.json()
        const products=peoductdatas.products

        // console.log(datas.products)
        setData(products)
    }
    useEffect(() => {
      
    fetchdata()
      
    }, [])
    
  return (
    <div className='flex flex-wrap '>

        {data.map((product,i)=>(
            <Card key={i} brand={product.brand} id={product.id} image={product.images} desc={product.description} title={product.title} price={product.price} />
            ))}
      
    </div>
  )
}

export default Apifetch
